# Initial context (local only)
No application implemented. Start F01 via README_START.md. Record assigned task, branch, commits, actual tests and blockers. Never record secrets or patient data.
