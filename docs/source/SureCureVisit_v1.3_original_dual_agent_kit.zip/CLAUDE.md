# SureCure Visit — Claude Code instructions (v1.3)
@AGENTS.md

Read the shared contract above and docs/MASTER_BLUEPRINT.md. If the import is unavailable, read AGENTS.md directly. Project instructions select Next.js, not the global Vite/Express/FastAPI preferences. The user authorizes routine autonomous development and feature-branch commits/pushes for this project; do not alter global configuration. Use Git Bash on Windows. Claude owns UI by default; Codex owns backend/contracts/migrations. Work only in the assigned worktree. Use Superpowers for one feature at a time, Impeccable for branding, Context7 when API details are uncertain, and Playwright for browser verification. Use /ctx-resume and /handoff if installed, with separate per-worktree notes and no secrets. Read docs/TOOLKIT.md and docs/AGENT_COORDINATION.md. Do not let /yourweb create a Vite project. Never override release gates. 

Read docs/MASTER_BLUEPRINT.md before changes. This is a real Indian healthcare marketplace, not a demo. Target client handover 23 Nov 2026; scope is the gated initial release, not all future features. If instructions conflict, stop and record a decision in docs/DECISIONS.md; do not invent business policy.

## Brand and business identity
Use SureCure Visit as the public brand and surecurevisit.in as the production domain. The legal business name is unconfirmed. Never invent or infer a company affiliation; obtain client approval before publishing legal or merchant identity details.

## Stack and structure
Next.js App Router, TypeScript strict, Tailwind, shadcn/ui, Zod, Supabase Postgres/Auth/Storage, SQL migrations, generated DB types, Vitest, Playwright. One modular monolith. Use src/modules domain services and server-only integrations; route handlers/server actions call shared services. Pin supported dependencies and lockfile. Do not add NestJS, Redis, microservices or new vendors without approval.

## Non-negotiable rules
- Six primary roles: patient, doctor, lab, ambulance, caretaker, admin. Provider can be individual or organization; staff have scoped memberships. Authorization on server and DB, never just UI. Deny by default; RLS on exposed tables and private storage. No client-side service-role secrets, no self-granted roles. Explicitly check record ownership, active membership and provider verification for mutations.
- Use synthetic data only; never read/copy production patient data into prompts, logs, tests or seeds. Never commit secrets or print tokens. .env.example contains names only. Follow docs/PERMISSIONS.md for autonomous work and coordinated production operations.
- Patient selects provider, provider manually accepts, provider sets price. Store immutable booking price in integer paise; UTC timestamps; resource overlap prevention in DB; idempotent requests and atomic state transitions. Booking status separate from payment status. No arbitrary client status changes.
- Payments: test mode default; server creates orders, verifies signatures and authoritative amounts/status; dedupe webhook events, reconcile late captures; no browser-only paid status. Pay-after is distinct. No card storage or developer merchant account.
- Emergency dispatch, clinical records, GPS, subscriptions, medicine fulfillment, live payments and automatic payouts disabled by server feature flags until approved. Visible emergency call 112 without login. No fake emergency ETA, fake providers, fake reviews, fake medical functionality. Scheduled ambulance only initially.
- No public clinical or verification file URLs; authorize each access, private storage, short-lived signed links. Audit sensitive operations, sanitize logs. Do not cache patient data publicly.

## Working method
1. Inspect existing repo and git status; do not overwrite unrelated changes. Read blueprint and current decisions. State planned files, data changes and tests.
2. Implement one vertical slice at a time: migration + RLS + domain service + UI + tests. Use smallest reviewable diff. No broad rewrites or mock production paths.
3. Migrations versioned and forward-compatible; no destructive changes without backup/approval. Run agent migrations against isolated local/dev databases; the integrator alone applies staging and approved production migrations. Generate types after migrations. Test actual role tokens and direct API denial.
4. Run lint, typecheck, unit/integration tests and relevant Playwright tests; run production build before handover. If commands unavailable, document exact blocker, never claim pass. Add scripts to package.json if missing. Do not suppress errors to pass tests.
5. Report changed files, tests with actual results, security implications, unresolved blockers, migration steps and next slice. Update docs/DECISIONS.md and checklist. Feature-branch commits and pushes are pre-authorized by the user; staging deployment may proceed under the agreed workflow. Main and production are owned by the designated integrator.

## Initial implementation order
A. Scaffold repo, docs, CI, environment validation, local/staging Supabase, design tokens and public layout.
B. Identity, patient profile, organization memberships, provider onboarding and admin verification; tests for cross-tenant and role escalation.
C. Four-category catalog, verified public listing/PIN coverage, provider prices and availability.
D. Shared booking request/accept/decline/cancel/complete with resource constraints, price snapshot and audit; patient/provider/admin dashboards.
E. Service-specific details (doctor visits, lab orders, scheduled ambulance, care duration), pay-after recording and test gateway only if core passes.
F. Accessibility, mobile, security, concurrency, error handling, backup/restore, client UAT and gated release.

## Definition of done
Working database-backed functionality; no placeholder success; server validation and permissions; migration and rollback notes; tests for happy path and denied access, concurrency and idempotency where relevant; responsive UI and error/empty/loading states; no secrets or sensitive logging; documented known limitations. A feature is not done merely because UI renders. If a release gate fails, keep feature disabled and report it. No claim of compliance/security certification without independent review.

## First session prompt
Inspect the repository and summarize what exists. If empty, scaffold only the foundation using the approved stack, create docs/DECISIONS.md and docs/RELEASE_CHECKLIST.md, add synthetic-only local setup and CI, and propose the identity/provider migration with RLS tests. Do not implement all dashboards, subscriptions, emergency dispatch or live payments in one session. Stop after a reviewable foundation and report actual test results.
