# Selected tools (from RepoVault and Claude setup README)
Use existing installations when available; no bulk install or copied global ~/.claude directory. Actual config/skills not inspected, only README and RepoVault documentation. Verify commands and versions locally before use.

| Tool | Use |
|---|---|
| Superpowers (obra/superpowers) | planning/TDD/debug/review per ticket |
| Impeccable + emil-design-eng | brand critique and UI polish |
| shadcn/ui | primary component library |
| Vercel React best practices/composition/web guidelines | performance, accessibility, component review |
| Context7 MCP | version-specific docs |
| Playwright MCP + webapp-testing | local browser exploration; actual Playwright tests for CI |
| owasp-security + code-reviewer | security review, not certification |
| deploy-to-vercel | authorized staging/release workflow |
| GitHub MCP / Chrome DevTools / DBX | optional if installed; DBX synthetic-only |
| GSD | optional ticket organization if installed; not a second plan |

Claude global README: Windows Git Bash, acceptEdits, Haiku default, Superpowers, /ctx-resume, /handoff, /usage, /understand, /generate-tests, /yourweb. Use stronger available model for complex auth/transactions, lighter for copy; no fixed model dependency. /yourweb must follow Next.js, not Vite. No /hackathon-mode for production gates. Codex reads AGENTS.md and uses its own available tools; Claude skills are not assumed installed in Codex. Project skills under .claude/skills are additional guidance only. Avoid extra starter kits, agent orchestrators, unofficial model proxies, clinical AI/RAG, and unneeded libraries. Check license before reusing components. Keep session history and credentials private.
