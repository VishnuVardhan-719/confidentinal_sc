# Decisions

Record date, decision, rationale, approver, and unresolved questions.

## 2026-11-16 — Brand identity correction
Public brand: SureCure Visit. Production domain: surecurevisit.in. Legal business name remains unconfirmed; do not associate the project with any other company without explicit client confirmation. User correction accepted.

## 2026-11-16 — v1.3 dual-agent workflow
User explicitly wants Claude and Codex side by side and autonomous development. Proposed split: Claude UI, Codex backend, integrator shared config/main/releases. Project-only permissions; separate worktrees and dev databases. User approved routine commits/pushes; client release authorization and sensitive data safeguards remain. Proposed branding tokens pending client approval. Monetization, legal identity, merchant terms, existing data and client operational coverage unresolved. No actual runtime configuration changed.
