# Parallel engineering protocol
One Git repository, two worktrees and a designated integrator (human or one agent selected by the human). Integration worktree holds main; Claude feature/claude-ui; Codex feature/codex-backend. Initial scaffold must be committed before worktree creation. See scripts/setup-worktrees.sh.

| Owner | Exclusive paths initially |
|---|---|
| Claude | src/app public/dashboard pages (not api), src/components, src/styles, DESIGN.md, UI tests |
| Codex | supabase/migrations, src/modules, src/app/api, generated DB types, backend tests, API_CONTRACTS.md |
| Integrator | package.json/lockfile, root configs, CI, shared lib/env, release docs, main, staging/prod |

Before work: integrator assigns task ID and base commit; agent checks clean status and records claimed paths in own handoff. For shared file edits request reassignment in handoff, then integrator coordinates. Codex publishes contract changes on its branch; integrator merges contract-only changes early, Claude rebases/merges main before wiring. Use typed fixtures only until backend ready; no mock success in released UI. One migration author at a time; immutable applied migrations, forward fixes only. Separate dev databases/ports or projects; do not reset shared staging. Each agent uses its own untracked .env.local and notes; never copy prod secrets.

Integration: agent tests and commits → peer review commit/diff → integrator merges in dependency order → full CI and staging smoke tests → update release checklist → authorized production release. Do not resolve conflicts by choosing all ours/theirs; reconcile contract and rerun tests. No simultaneous deployments or migrations. Pause affected task if contract missing or failing; work on independent ticket.

Handoff template (one per agent): task ID; branch/base/commit; owned paths; changes; API/migration revision; test commands/results; review findings; blockers; next ticket; flags. Never include tokens or patient data. Use local .context/activeContext.md or docs/handoffs/<agent>.md with synthetic-only content; integrator records shared decisions.
