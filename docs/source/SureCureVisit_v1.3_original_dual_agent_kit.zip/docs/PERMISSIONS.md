# Autonomy and permissions
User decision: maximum autonomy for both agents on SureCure Visit; no repeated approval for routine coding. Scope is this repository and isolated development resources. User permission is not proof of client authority or actual tool credentials.

| Action | Rule |
|---|---|
| Source edits, dependency installs, shell tests/builds, local migrations | Autonomous within assigned worktree; inspect dependency scripts and SQL; no secrets |
| Git branches, commits, pushes | Autonomous on assigned feature branches; no force push, main changes only integrator |
| Dev DB/MCP | Restricted synthetic environment; isolated per agent |
| Staging deployment/migrations | Integrator executes agreed workflow, isolated data and credentials; agents may prepare previews |
| Production deployment, DNS, merchant configuration, production migrations | Designated integrator executes after recorded client authorization and green release gates; one authorization may cover planned batch |
| Real patient DB/MCP | No unrestricted agent access; authorized human-controlled migration/operations outside agent sessions |
| Destructive production deletion, live charges/refunds, secret export | Not routine autonomous work; require separately authorized operational process, backups and audit; never expose secrets |

Actual Claude/Codex runtime permissions are not changed by this document. Keep project-only settings, avoid global bypass or unrestricted production credentials. If sandbox or tool asks for approval, do not circumvent it. No new paid service charges without client budget authorization. Use least-privilege credentials even when routine actions are pre-authorized.

The included `.claude/settings.json` is a conservative project template, not a global override: acceptEdits and common checks are preallowed; destructive commands and direct production deploy/DB push patterns prompt. Existing global rules may still prompt (including git commit/push); the user can authorize those through the CLI. No blanket bypass, no Codex sandbox modification. This is intentional: the autonomy policy is broad, but actual execution remains subject to tool controls and safe release ownership. Review against installed CLI version before use.
