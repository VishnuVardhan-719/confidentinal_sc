# November 16–23 implementation board
Targets, not guaranteed delivery. Mark done only with real tests. Integrator assigns work; both agents can work in parallel after scaffold/contract freeze. If behind, cut optional features not tests. Private staging handover if release gates fail.

| Date / ID | Claude (UI) | Codex (backend) | Acceptance / dependency |
|---|---|---|---|
| 16 F01 | design tokens, layout plan | schema and API plan | integrator initializes single Next app, CI, env, first commit; freeze identity contract |
| 17 I01 | login/onboarding/admin verification screens | auth, profiles, org membership, RLS, verification | role escalation and cross-org denial tests pass |
| 18 C01 | four discovery pages, profile, PIN selector | catalog/prices/coverage queries | only verified published providers; no fabricated records |
| 19 B01 | request form, patient/provider booking dashboard | atomic booking/accept/decline/cancel, idempotency, overlap | concurrent accept test, frozen price, unauthorized mutations denied |
| 20 S01 | service details and pay-after UX | doctor/lab/scheduled transport/care details, payment records; test gateway if time | all four request flows, payment-state separation |
| 21 Q01 | responsive/accessibility E2E | RLS/concurrency/payment tests, review | full CI; no critical defects; backup/restore rehearsal |
| 22 U01 | client UAT, branding fixes | bug fixes, migration/deployment verification | feature freeze; client terms, coverage, release decision |
| 23 R01 | handover and smoke test | integrator release/rollback, evidence | approved candidate; public transactional features only if gates pass |

Dependencies F01 → I01 → C01 → B01 → S01 → Q01 → U01 → R01. UI may use synthetic typed fixtures until API is merged; remove mocks before release. Basic family profiles only if access tests pass. Deferred: emergency dispatch, subscriptions, pharmacy, clinical reports, GPS, payouts, live payments until separate gates. For each ticket record owner, branch, commit, acceptance tests, blockers and peer review. No deadline-based override of safety gates.
