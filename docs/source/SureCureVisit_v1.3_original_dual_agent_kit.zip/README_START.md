# SureCure Visit v1.3 — Dual Agent Edition
This is a specification kit, not a working application. Extract into a new project folder; preserve existing code if merging into a repository. Windows Git Bash recommended. Read MASTER_BLUEPRINT, AGENTS, DESIGN, IMPLEMENTATION_TASKS and PERMISSIONS. No secret files included. Actual Claude/Codex installations, permissions and accounts remain unchanged.

1. In project root run `git init -b main` if not already a repository. Review files and commit the kit (`git add . && git commit -m "Add SureCure Visit v1.3 blueprint"`). Configure Git identity if needed. Do not commit existing secrets.
2. Open Claude or Codex as the designated integrator. Paste the bootstrap prompt below. Scaffold exactly one app, preserve docs, run checks and commit foundation to main. No live credentials or purchases.
3. Run `bash scripts/setup-worktrees.sh` from main after the foundation commit. It creates sibling directories and branches. Open separate terminals in each, start `claude` and `codex` respectively (if installed). Read AGENTS.md and assigned task prompt. Install deps separately in each worktree using the same lockfile; isolate environment files and DBs. Use separate ports e.g. 3001/3002.
4. Integrator coordinates contracts, merges reviewed commits, tests, staging and release. Do not run both agents in same directory. Worktree creation script does not push, deploy or create remote resources.

## Bootstrap prompt (one agent only)
Read AGENTS.md, CLAUDE.md, docs/MASTER_BLUEPRINT.md and docs/IMPLEMENTATION_TASKS.md. Act as integrator for F01. Inspect repository. If no app exists, scaffold one Next.js App Router TypeScript application, Tailwind/shadcn foundation, environment validation, lint/typecheck/test/build scripts, CI and synthetic-only Supabase local setup. Preserve all kit docs. Pin supported versions, use one lockfile. Do not build all dashboards or apply remote migrations. Plan and report files, run checks, commit foundation if green, record blockers and contract decisions. Then stop for worktree setup.

## Claude prompt
Read AGENTS.md and CLAUDE.md, then docs/AGENT_COORDINATION.md, DESIGN.md, API_CONTRACTS.md and task board. You own UI worktree. Start assigned UI ticket only; use agreed contracts, no backend/migration/root config edits. Use Superpowers and Impeccable if installed. Run tests and commit your branch; hand off actual results and request peer review. Never deploy independently.

## Codex prompt
Read AGENTS.md and docs/MASTER_BLUEPRINT.md, AGENT_COORDINATION.md, API_CONTRACTS.md, IMPLEMENTATION_TASKS.md. You own backend worktree. Start assigned backend ticket; publish typed contracts, migrations, RLS and negative tests before UI integration. Use synthetic local DB only. Run checks and commit your branch; hand off results and request peer review. Never deploy independently.
