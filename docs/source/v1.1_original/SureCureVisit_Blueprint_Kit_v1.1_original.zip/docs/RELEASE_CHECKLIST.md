# Release checklist

- [ ] Client scope approval
- [ ] RLS and role tests
- [ ] Booking concurrency and payment tests
- [ ] Security and privacy review
- [ ] Backups and rollback rehearsal
- [ ] Client UAT
- [ ] Domain and production approval
