# Risks and blockers

- Existing application/repository state has not yet been inspected in the execution environment.
- Referenced detailed v1.5 specification files are missing from supplied archives; see SOURCE_INVENTORY.md.
- Claude/Codex/Kiro model IDs, effort settings, CLI versions, permissions and native delegation capabilities must be verified at execution start.
- Legal business identity, client-approved terms, provider coverage and credentials remain unconfirmed.
- Existing website source, Firebase inventory, data migration and rollback remain unknown.
- Domain/DNS ownership/access and production account ownership must be verified.
- OTP/SMS/email vendors and costs require approval.
- Merchant account, settlement, tax, cancellation, refund and payment policies require approval.
- Clinical data hosting/retention/consent and applicable legal requirements need qualified review.
- Emergency dispatch is not enabled and requires real operational readiness.
- November 23 target is aggressive; staging acceptance may be the safe outcome.
