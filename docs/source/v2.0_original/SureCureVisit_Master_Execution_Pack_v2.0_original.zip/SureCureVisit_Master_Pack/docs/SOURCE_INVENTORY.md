# Source inventory and limitations

## Supplied and preserved
- Original SureCure Visit v1.5 project handbook.
- Original v1.5 day-by-day plan.
- Separately uploaded SureCure Visit Master Blueprint v1.1.
- v1.3 Blueprint Kit: CLAUDE.md, AGENTS.md, DESIGN.md, README_START.md, master blueprint, agent coordination, API contracts, decisions, implementation task board, permissions, release checklist, toolkit, Claude project settings, four project skills, active context note and worktree script.

## Important reconciliation
- v1.5 handbook says PLANNING ONLY and START required. The owner later explicitly authorized development in conversation. This README records that the old status is superseded, while requiring a direct resume instruction before the next implementation session.
- v1.3 assigns Claude UI and Codex backend. Superseded by Claude orchestration + Codex/Kiro delegation.
- v1.3 and v1.5 mention Antigravity editor/inspector. Owner later removed Antigravity and disbanded AI Dev Kit; this is the current workflow.
- Owner initially handles both frontend and backend; friend joins later, primarily for pending frontend work.

## Missing referenced documents
The v1.5 handbook references detailed documents including PRODUCT_REQUIREMENTS.md, SYSTEM_ARCHITECTURE.md, DATABASE_SCHEMA.md, ROLE_ONBOARDING_AND_PERMISSIONS.md, BOOKING_AND_CONSULTATION.md, TECH_STACK_AND_SUBSCRIPTIONS.md, AI_WHATSAPP_AND_CLOUD.md, DESIGN_ANIMATION_I18N.md, RISKS_OPEN_DECISIONS.md, CLIENT_HANDOVER_AND_OPERATIONS.md and EXISTING_SITE_AND_MIGRATION.md. These were not present as separate files in the supplied archives inspected for this pack. Some of their content is summarized in the v1.5 handbook or v1.1 blueprint, but do not claim to have read their full versions. Create/reconstruct them only as clearly labeled derived specs if needed, and keep gaps visible.

## Original archives
The original uploaded archives should be retained outside this pack as source backups. Do not delete or overwrite them.
