# SureCure Visit — live implementation task ledger

**Initial state:** Prepared; implementation has not been verified as started in this pack.  
**Human owner:** Project owner.  
**Orchestrator:** Claude Code.  
**Delegated agents:** Codex CLI, Kiro CLI.  
**Future human handover:** Friend, primarily pending frontend/UI work.

> Update this file continuously. Do not mark work done based on an agent's claim. Link commits and actual test evidence.

## Status definitions
- `DONE_VERIFIED`: implemented, reviewed and tests executed successfully.
- `IMPLEMENTED_UNVERIFIED`: code exists but required verification is incomplete.
- `IN_PROGRESS`: active work.
- `PENDING_HANDOVER`: independent work ready for the friend or another developer.
- `BLOCKED`: cannot proceed due to missing dependency/decision/access.
- `DEFERRED_BY_DESIGN`: deliberately excluded or feature-gated.

## Initial workstreams

| ID | Workstream | Initial human owner | Agent assignment | Priority | Status | Dependencies / exit evidence |
|---|---|---|---|---|---|---|
| R00 | Repository/source/tool reconnaissance and model/effort verification | Owner | Claude orchestrates; Codex/Kiro inspect assigned areas | P0 | IN_PROGRESS when resumed | Inventory, actual CLI/model settings, Git status, source gaps, no secrets exposed |
| F01 | App foundation, strict TS, design tokens, env validation, CI and tests | Owner | Claude/Codex/Kiro by isolated ticket | P0 | PENDING | One app, one lockfile, lint/typecheck/test/build, clean commit |
| I01 | Auth, profiles, roles, organizations, memberships, RLS | Owner | Codex/Kiro implementation/review as assigned | P0 | PENDING | Role escalation and cross-org denial tests |
| I02 | Provider onboarding, private docs, admin verification | Owner | Codex/Kiro | P0 | PENDING | Only approved providers published; expiry/suspension tested |
| C01 | Verified catalog, services, pricing, PIN coverage and public discovery | Owner | Claude/Kiro/Codex by ticket | P0 | PENDING | No fake coverage/listings; public/private separation |
| B01 | Shared booking engine, price snapshot, accept/decline/cancel, events | Owner | Codex primary implementation/review if assigned | P0 | PENDING | Atomic acceptance, idempotency, concurrency, actor scope |
| S01 | Doctor, lab, scheduled ambulance and caretaker workflows | Owner | Codex/Kiro by independent module | P1 | PENDING | One real DB-backed tested journey per enabled category |
| P01 | Pay-after records, test payments, webhooks and reconciliation | Owner | Codex primary review/implementation if assigned | P1 | PENDING | Payment separate from booking; signature/dedupe tests |
| U01 | Patient/provider/admin dashboards and responsive UI | Owner initially | Claude/Kiro/Codex as assigned | P1 | PENDING | Real APIs; loading/error/empty states; mobile/keyboard tests |
| Q01 | Security, RLS, E2E, accessibility, performance, backup/restore | Owner | Codex/Kiro independent reviews | P0 | PENDING | Evidence recorded; no critical/high release blockers |
| H01 | Friend frontend handover package | Owner/Claude | Claude prepares; friend executes later | P2 | PENDING | Branch, setup, contracts, pending UI tickets, tests and next actions |
| R01 | Staging, client acceptance, runbook and release decision | Owner | Claude coordinates | P0 | PENDING | Explicit client approval and all relevant release gates |

## Rules

- Owner initially directs both frontend and backend; do not assume friend is already working.
- Assign each agent an exclusive file scope and separate worktree.
- Do not assign two agents the same files concurrently.
- Record task IDs, branch, base commit, commits, changed files, dependencies, acceptance criteria, test evidence, blockers and next action.
- Keep future frontend tasks independently handoff-ready.
- Cut optional features before cutting security or test requirements.
