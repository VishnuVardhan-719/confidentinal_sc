# Release checklist

- [ ] Client scope approval
- [ ] RLS and role tests
- [ ] Booking concurrency and payment tests
- [ ] Security and privacy review
- [ ] Backups and rollback rehearsal
- [ ] Client UAT
- [ ] Domain and production approval

- [ ] Cross-agent contract and migration review; full integration CI
- [ ] All four scheduled/manual service flows tested with real database and synthetic fixtures
- [ ] No production mock data; unapproved feature flags off; emergency 112 visible
- [ ] Client legal identity/terms, verified provider coverage, infrastructure ownership confirmed
- [ ] Design approved, keyboard/mobile tests pass, no secrets in repo or logs
- [ ] Payment test mode verified; live activation separate approval and reconciliation
- [ ] Release hash, backup/restore evidence, rollback runbook and designated integrator recorded
- [ ] Existing data audit/migration plan or explicit decision not to migrate
- [ ] If any required gate fails, private staging handover only; document blockers
