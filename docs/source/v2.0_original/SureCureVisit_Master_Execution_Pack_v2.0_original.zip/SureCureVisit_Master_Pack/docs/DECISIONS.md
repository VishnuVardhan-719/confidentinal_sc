# SureCure Visit — decisions and open questions

Record date, decision, rationale, approver, source and unresolved questions. Do not turn proposals into client-approved policy.

## 2026-11-16 — Brand identity
- Public brand: SureCure Visit.
- Production domain: `surecurevisit.in`.
- Legal business name remains unconfirmed; do not infer another company affiliation.

## 2026-11-17 — Human-controlled orchestration (current)
- Claude Code is lead orchestrator.
- Codex CLI and Kiro CLI are delegated engineering agents.
- Project owner directly controls Claude and makes final decisions.
- Owner initially directs/starts both frontend and backend development.
- Friend joins later and is expected to take pending frontend/UI tasks through documented handover.
- Antigravity and AI Dev Kit are removed from active workflow.
- Claude must verify actual CLI versions, supported model/effort settings and delegation capabilities; do not invent support.
- One shared repository; isolated worktrees for concurrent coding agents.

## 2026-11-17 — Startup prompt location
- Root `README.md` is the single master execution prompt and primary entrypoint.
- Heavy prompts must be stored in repository README/docs, not pasted into chat.
- New sessions use a short resume instruction and read the current task ledger/session log.

## Pending client/project decisions
- Legal business identity and approved legal copy.
- Logo and final brand approval.
- Existing website repository/data inventory and migration decision.
- Verified provider coverage and credentials.
- OTP/email/SMS vendor and costs.
- Merchant account, settlement model, taxes, refund/cancellation policy.
- Request expiry/payment hold policy (30-minute request expiry and 15-minute payment hold are proposals only).
- Medical data hosting, retention, consent and legal review.
- Emergency dispatch operating model; disabled until independently approved.
- Membership benefits/prices and licensed pharmacy partner; deferred.
- Domain/DNS access and cutover authority.
- Client-owned hosting, database, monitoring and recovery accounts.
