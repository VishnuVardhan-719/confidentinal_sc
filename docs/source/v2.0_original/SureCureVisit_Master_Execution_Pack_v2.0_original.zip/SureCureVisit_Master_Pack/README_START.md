# Start / Resume SureCure Visit

This is now a pointer file. The complete master startup prompt lives in the root **`README.md`**. Do not paste a large prompt from chat.

## To start or resume

1. Open Claude Code in this project root.
2. Ensure the current working tree and project files are accessible.
3. Send this short instruction:

   > Read `README.md` and resume SureCure Visit from the current task ledger. Verify the strongest available Claude model and effort, inspect Codex/Kiro capabilities, then continue execution. I control Claude; you orchestrate the other agents. Do not restart completed work.

4. Claude must read the README and current state files before editing.

## Important

- Claude Code is the orchestrator.
- Codex CLI and Kiro CLI are delegated agents.
- The owner initially directs both frontend and backend work.
- The friend joins later and takes pending frontend/UI work through a handover.
- Antigravity and AI Dev Kit are not used.
- Do not start merely by opening this file; wait for the owner's direct resume instruction.
- Do not overwrite existing work or claim tests pass without running them.
