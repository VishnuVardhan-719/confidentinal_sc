# Active SureCure Visit context

Root `README.md` is the master execution prompt. Claude is the orchestrator; Codex and Kiro are delegated agents. The owner initially directs both frontend and backend. The friend joins later for pending frontend/UI work. Antigravity and AI Dev Kit are removed.

At resume: inspect Git and actual repository state, read `docs/IMPLEMENTATION_TASKS.md`, `docs/SESSION_LOG.md`, `docs/DECISIONS.md` and `docs/HANDOVER.md`; verify model/effort and CLI capabilities. Do not assume work is complete without commits/tests. Never record secrets or patient data here.
