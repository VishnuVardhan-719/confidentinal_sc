# SureCure Visit — proposed rebrand design system
Client approval pending; this is a proposed visual direction, not final logo or brand approval. Calm, modern healthcare marketplace, mobile first; no stock claims of clinical outcomes or guaranteed coverage.

| Token | Value |
|---|---|
| Primary | #087E76 |
| Primary dark | #075B56 |
| Ink | #142C36 |
| Muted | #52656B |
| Background | #F6FAF9 |
| Surface | #FFFFFF |
| Border | #DCE7E4 |
| Error | #B42318 |
| Focus | #145BCC |

Use next/font with a legible sans (e.g. Geist), fallback system; body 16px, line-height 1.5; 4/8 spacing scale; 12px cards, clear focus rings; verify WCAG AA contrast for actual foreground/background combinations. Use text labels plus icons, never color alone. Touch targets at least 44px where possible. Avoid excessive gradients, glass, autoplay or animation; respect reduced motion. Use licensed imagery, no fabricated doctor credentials or reviews. Logo placeholder is simple wordmark until approved.

Public: header location selector, four service categories, clear provider availability, transparent price, trust/verification explanation, emergency 112 link, footer legal/support. Search filter by PIN and category; empty state shows no service coverage, not fake listings. Profile shows real credentials, services, terms, request CTA. Booking form summarizes patient, provider, time, price and payment choice; explicitly pending provider acceptance. Mobile stacked cards; desktop max width ~1200px, responsive grid. Dashboard shell: shared sidebar desktop, accessible mobile navigation, status badges with text, tables collapse to cards, loading/error/empty states. Admin prioritizes verification queue and booking exceptions. Membership pages informational only until approved. Use shadcn components and Lucide; Impeccable for critique, Emil for restrained polish; no extra animation library unless justified. All screens test 360/768/1280 widths, keyboard and reduced motion. Do not hide overflow to mask layout defects.
