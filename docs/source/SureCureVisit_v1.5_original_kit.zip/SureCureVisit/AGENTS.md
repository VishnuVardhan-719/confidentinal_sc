# v1.5 UPDATE — authoritative planning guardrail

**No implementation until owner explicitly says START.** This is a planning specification. Read README and `docs/DECISIONS.md` first when authorized. Codex CLI primarily owns Supabase Postgres schema/migrations, org and patient RLS, booking acceptance, public references, OTP, clinical persistence, finance and negative tests; Claude CLI primarily owns custom UI/UX. Both work in isolated Git worktrees after one common foundation. Antigravity **only for editing**. Keep server-only Ollama Cloud API and **no paid fallback**, Three.js/Anime.js/21st.dev accessible design, locale `en/te/hi`, mandatory but truthful patient questionnaire, all 14 requested clinical features with verification. Never imply unverified features are safe for production. No guessed legal entity.

---

# SureCure Visit — shared agent contract (v1.3)
Applies to Claude Code and Codex. Read docs/MASTER_BLUEPRINT.md, DECISIONS.md, AGENT_COORDINATION.md, API_CONTRACTS.md, IMPLEMENTATION_TASKS.md, PERMISSIONS.md and DESIGN.md before claiming a task. Product spec controls business rules; this contract controls execution. Escalate genuine conflicts to the project lead rather than inventing policy.

## Product and stack
SureCure Visit, surecurevisit.in, legal business name unconfirmed. Real Indian healthcare marketplace; patient chooses provider, provider sets prices and manually accepts. Six roles, individuals and organizations with scoped staff. Both online and pay-after-service. Nationwide discovery only where verified coverage exists. Nov 23 2026 acceptance candidate; ₹10,000 development budget, infrastructure separate. Next.js App Router, strict TypeScript, Tailwind/shadcn, Zod, Supabase PostgreSQL/Auth/private Storage, SQL migrations/generated types, Vitest/Playwright, GitHub/Vercel, Razorpay test mode. No alternative stack or unnecessary new services. Clinical files, live payments, emergency dispatch, GPS, pharmacy, paid plans, recurring billing and payouts disabled until gates pass. Emergency call 112 visible without login.

## Execution
- Claude: public UI, design tokens, dashboards. Codex: migrations, RLS, domain services, routes, contracts, backend tests. Integrator owns shared package lock, root config, main, release and shared staging migrations. Explicit task reassignment is allowed. Worktree/branch ownership is mandatory.
- Before editing inspect git status, read assigned ticket and contract, report plan and files. Never overwrite unrelated changes. No broad refactors. Use synthetic data only, separate local databases and unique ports. Read peer commits through Git, not by editing peer worktree.
- Keep secrets out of source, logs, prompts, session notes and fixtures. Never connect AI tools to real patient records. Deny access by default in server and RLS; check ownership, active membership and verified status. No self-granted admin. Private files only, short-lived authorized links. Avoid shared caches for private data.
- Booking price snapshot in integer paise; UTC intervals; atomic state transition, version check, idempotency, non-overlap constraints. Payment state separate; verify webhook signature and gateway amount/status; late capture reconciliation. Never trust client price, role or paid status.
- Validate with lint, typecheck, unit/integration, relevant E2E and build. Add denial and concurrency tests for critical mutations. Record actual output and blockers; do not claim passing tests without execution. No fake production records or functionality.
- Commit/push own feature branch autonomously, no force push. Cross-review critical code. Integrator merges only green changes and executes controlled releases. Follow docs/PERMISSIONS.md, no disabling safety controls or destructive production changes.
- At handoff record task, commit, files, contract/migration version, actual test results, blockers, next steps and feature flags. No secrets. A working UI alone is not done.

## Start
Read README_START.md; inspect repo. If no app exists, integrator scaffolds one foundation first, commits it, then creates worktrees. Do not scaffold separate apps or generate all features at once. Follow ticket order and release checklist.
