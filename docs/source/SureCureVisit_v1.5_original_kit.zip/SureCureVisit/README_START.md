# SureCure Visit v1.5 — Start Here (PLANNING ONLY)

**Nothing has been built.** Project owner explicitly required **NO CODING, NO CLI PROMPTS AND NO DEVELOPMENT UNTIL THEY SAY START**. This is a comprehensive planning kit, not an installation guide to run now.

Read in sequence: `README.md` → `docs/DECISIONS.md` → `docs/PRODUCT_REQUIREMENTS.md` → `docs/TECH_STACK_AND_SUBSCRIPTIONS.md` → `docs/DAY_BY_DAY_PLAN.md` → remaining documents. The earlier v1.3 kit contained premature bootstrap prompts; those are removed from the active README_START.

Scope: six roles, pan-India verified coverage, rich doctor consultation/OTP/status, lab/ambulance/caretaker, cloud db, 3 languages, website AI free-only Ollama Cloud, WhatsApp, memberships, full rebranding and high development autonomy. November 23 is client target, not automatically a secure live go-live.

After explicit START, assign a foundation integrator, agree typed schema/contracts, then two worktrees. Review the included **future-use** script `scripts/setup-worktrees.sh` before executing; it is not run by extracting this archive. Client data and production payment credentials never enter sample project files.
